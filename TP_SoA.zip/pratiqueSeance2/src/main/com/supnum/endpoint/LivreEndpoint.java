package com.supnum.endpoint;

import com.supnum.livre.*; // Importez toutes les classes générées
import com.supnum.service.LivreService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ws.server.endpoint.annotation.Endpoint;
import org.springframework.ws.server.endpoint.annotation.PayloadRoot;
import org.springframework.ws.server.endpoint.annotation.RequestPayload;
import org.springframework.ws.server.endpoint.annotation.ResponsePayload;

@Endpoint
public class LivreEndpoint {
    private static final String NAMESPACE_URI = "http://supnum.com/livre";

    @Autowired
    private LivreService livreService;

    // 1. GetLivre (par ISBN)
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetLivreRequest")
    @ResponsePayload
    public GetLivreResponse getLivre(@RequestPayload GetLivreRequest request) {
        GetLivreResponse response = new GetLivreResponse();
        Livre livre = livreService.getLivreByIsbn(request.getIsbn());
        response.setLivre(livre);
        return response;
    }

    // 2. GetAllLivres
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "GetAllLivresRequest")
    @ResponsePayload
    public GetAllLivresResponse getAllLivres(@RequestPayload GetAllLivresRequest request) {
        GetAllLivresResponse response = new GetAllLivresResponse();
        response.getLivre().addAll(livreService.getAllLivres());
        return response;
    }
    
    // 3. AddLivre
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "AddLivreRequest")
    @ResponsePayload
    public AddLivreResponse addLivre(@RequestPayload AddLivreRequest request) {
        AddLivreResponse response = new AddLivreResponse();
        String status = livreService.addLivre(request.getLivre());
        response.setStatus(status);
        return response;
    }

    // 4. UpdateLivre
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "UpdateLivreRequest")
    @ResponsePayload
    public UpdateLivreResponse updateLivre(@RequestPayload UpdateLivreRequest request) {
        UpdateLivreResponse response = new UpdateLivreResponse();
        String status = livreService.updateLivre(request.getLivre());
        response.setStatus(status);
        return response;
    }
    
    // 5. DeleteLivre
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "DeleteLivreRequest")
    @ResponsePayload
    public DeleteLivreResponse deleteLivre(@RequestPayload DeleteLivreRequest request) {
        DeleteLivreResponse response = new DeleteLivreResponse();
        String status = livreService.deleteLivre(request.getIsbn());
        response.setStatus(status);
        return response;
    }
    
    // 6. EmpruntLivre
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "EmpruntLivreRequest")
    @ResponsePayload
    public EmpruntLivreResponse empruntLivre(@RequestPayload EmpruntLivreRequest request) {
        EmpruntLivreResponse response = new EmpruntLivreResponse();
        String status = livreService.empruntLivre(request.getIsbn());
        response.setStatus(status);
        return response;
    }
    
    // 7. ReturnLivre
    @PayloadRoot(namespace = NAMESPACE_URI, localPart = "ReturnLivreRequest")
    @ResponsePayload
    public ReturnLivreResponse returnLivre(@RequestPayload ReturnLivreRequest request) {
        ReturnLivreResponse response = new ReturnLivreResponse();
        String status = livreService.returnLivre(request.getIsbn());
        response.setStatus(status);
        return response;
    }
}