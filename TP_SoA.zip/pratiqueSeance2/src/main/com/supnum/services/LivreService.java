package com.supnum.service;

import com.supnum.livre.Livre; // Importez la classe générée
import org.springframework.stereotype.Service;
import java.util.*;

@Service
public class LivreService {
    // Utilisation d'une Map pour simuler la base de données (clé = ISBN)
    private final Map<String, Livre> livres = new HashMap<>();

    public LivreService() {
        // Initialisation avec des données de test
        Livre livre1 = new Livre();
        livre1.setIsbn("978-2070368291");
        livre1.setTitre("L'Étranger");
        livre1.setAuteur("Albert Camus");
        livre1.setAnneePublication(1942);
        livre1.setDisponible(true);
        livres.put(livre1.getIsbn(), livre1);

        Livre livre2 = new Livre();
        livre2.setIsbn("978-2070413113");
        livre2.setTitre("1984");
        livre2.setAuteur("George Orwell");
        livre2.setAnneePublication(1949);
        livre2.setDisponible(false);
        livres.put(livre2.getIsbn(), livre2);
    }

    // 1. GetLivre
    public Livre getLivreByIsbn(String isbn) {
        return livres.get(isbn);
    }

    // 2. GetAllLivres
    public List<Livre> getAllLivres() {
        return new ArrayList<>(livres.values());
    }

    // 3. AddLivre
    public String addLivre(Livre livre) {
        if (livres.containsKey(livre.getIsbn())) {
            return "Échec: Le livre avec ISBN " + livre.getIsbn() + " existe déjà.";
        }
        livres.put(livre.getIsbn(), livre);
        return "Succès: Livre ajouté.";
    }

    // 4. UpdateLivre
    public String updateLivre(Livre updatedLivre) {
        if (!livres.containsKey(updatedLivre.getIsbn())) {
            return "Échec: Livre non trouvé pour l'ISBN " + updatedLivre.getIsbn();
        }
        livres.put(updatedLivre.getIsbn(), updatedLivre);
        return "Succès: Livre mis à jour.";
    }

    // 5. DeleteLivre
    public String deleteLivre(String isbn) {
        if (!livres.containsKey(isbn)) {
            return "Échec: Livre non trouvé pour l'ISBN " + isbn;
        }
        livres.remove(isbn);
        return "Succès: Livre supprimé.";
    }
    
    // 6. EmpruntLivre
    public String empruntLivre(String isbn) {
        Livre livre = livres.get(isbn);
        if (livre == null) {
            return "Échec: Livre non trouvé pour l'ISBN " + isbn;
        }
        if (livre.isDisponible()) {
            livre.setDisponible(false);
            return "Succès: Livre emprunté.";
        } else {
            return "Échec: Livre déjà emprunté.";
        }
    }
    
    // 7. ReturnLivre
    public String returnLivre(String isbn) {
        Livre livre = livres.get(isbn);
        if (livre == null) {
            return "Échec: Livre non trouvé pour l'ISBN " + isbn;
        }
        if (!livre.isDisponible()) {
            livre.setDisponible(true);
            return "Succès: Livre retourné.";
        } else {
            return "Échec: Le livre n'était pas marqué comme emprunté.";
        }
    }
}