package com.supnum;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoapBibliothequeTpApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoapBibliothequeTpApplication.class, args);
    }

}